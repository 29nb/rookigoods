# rooki goods 🧣

Small square. Big energy. A static storefront (React + Vite) for Rooki Goods bandanas.

## Run it
```
pnpm install
pnpm dev:static      # http://localhost:3000
pnpm build:pages     # builds the site into docs/ for GitHub Pages
```

## Where things live
- `client/src/App.tsx` — every page (home, shop, product, how to tie, story, bag, checkout)
- `client/src/Bandana.tsx` — the product art. Each bandana is drawn in code, so it never breaks or blurs.
  Change colors and patterns in the `products` list in App.tsx.
- `client/src/styles.css` — the look
- `client/src/store.config.ts` — store settings: email, Instagram, shipping, **payment links**

## Going live (the real-store checklist)
1. **Host it free:** push this folder to a GitHub repo, then in Settings → Pages set the source to "GitHub Actions".
   `.github/workflows/pages.yml` deploys on every push to `main`.
2. **Take real payments:** create a Stripe account, make a Payment Link for each bandana
   (turn on "adjustable quantity"), and paste the links into `store.config.ts`.
   Never collect card numbers on your own site.
3. **Email signup:** the form is a demo right now. Hook it up to a free Mailchimp/Kit/Buttondown form.
4. **Real photos:** swap the crew photos in `client/public/assets/rookigoods/`.
