# Product and editorial photo sources

The catalog now uses a new consistent studio-packshot set for all four bandanas. Each packshot is a square 1:1 ecommerce composition with the whole bandana visible, matching soft lighting, neutral backgrounds, no people, no props, and no UI labels or watermarks:

- The Classic / Cherry — `catalog-classic.jpg`
- The Daydream / Cobalt — `catalog-daydream.jpg`
- The Field Trip / Moss — `catalog-field-trip.jpg`
- The Happy Hour / Butter — `catalog-happy-hour.jpg`

The generated packshots are currently referenced from the project’s managed image storage paths under `/manus-storage/async-images/SrFwsfvACmhcZYy6mPURRK/`. The local previous photos remain only for editorial campaign sections and fallback continuity.

The male-model campaign and nature layers remain separate from the ecommerce product images so the buying path stays clear: model imagery is used for styling context, while nature imagery is used for brand storytelling.
