/**
 * Store settings — edit these to go live.
 *
 * PAYMENTS: Never collect card numbers on your own site. Create a Stripe
 * Payment Link for each bandana (stripe.com → Payment Links, turn on
 * "let customers adjust quantity") and paste the URLs below. When a link is
 * set, checkout sends the shopper to Stripe's secure page. When every link is
 * empty the site runs in demo mode and no money moves.
 */
export const STORE = {
  name: "rooki goods",
  email: "hello@rookigoods.com",
  instagram: "https://instagram.com/rookigoods",
  freeShippingOver: 50,
  flatShipping: 6,
  paymentLinks: {
    classic: "",
    daydream: "",
    "field-trip": "",
    "happy-hour": "",
    "night-owl": "",
    crush: "",
  } as Record<string, string>,
};
