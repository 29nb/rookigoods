import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, ArrowUpRight, Check, ChevronDown, Menu, Minus, Plus, Shuffle, ShoppingBag, Sparkles, X } from "lucide-react";
import { Bandana, type Colorway } from "./Bandana";
import { STORE } from "./store.config";
import "./styles.css";

/* ───────────────────────── data ───────────────────────── */

type Product = {
  id: string;
  name: string;
  color: string;
  vibe: string;
  blurb: string;
  price: number;
  tag?: string;
  colorway: Colorway;
  bg: string;
};
type CartItem = { id: string; qty: number };

const products: Product[] = [
  { id: "classic", name: "The Classic", color: "Cherry", vibe: "main character", blurb: "Paisley, but make it loud. The one that started it all.", price: 24, tag: "bestseller",
    colorway: { base: "#f2482f", ink: "#2b1a3d", pop: "#ffd84d", light: "#fff3e6", motif: "paisley", center: "paisley" }, bg: "var(--butter)" },
  { id: "daydream", name: "The Daydream", color: "Cobalt", vibe: "head in the clouds", blurb: "Little sparkles for big ideas and long bus rides.", price: 24, tag: "new",
    colorway: { base: "#5560ff", ink: "#1c1650", pop: "#ffb3d9", light: "#fff3e6", motif: "sparkle", center: "sparkle" }, bg: "var(--lilac)" },
  { id: "field-trip", name: "The Field Trip", color: "Moss", vibe: "touch grass", blurb: "Tiny mushrooms for people who take the long way.", price: 24,
    colorway: { base: "#4fae6a", ink: "#173a24", pop: "#ff8a3d", light: "#fff3e6", motif: "mushroom", center: "mushroom" }, bg: "var(--mint)" },
  { id: "happy-hour", name: "The Happy Hour", color: "Butter", vibe: "sunny side up", blurb: "Cherries on a yellow square. Instant good mood.", price: 24,
    colorway: { base: "#ffd84d", ink: "#4a2410", pop: "#f2482f", light: "#fff8ea", motif: "cherry", center: "cherry" }, bg: "var(--bubble)" },
  { id: "night-owl", name: "The Night Owl", color: "Ink", vibe: "after dark", blurb: "Lightning bolts on midnight. For late shows and later plans.", price: 26, tag: "limited",
    colorway: { base: "#2b1a3d", ink: "#cdbcff", pop: "#ffd84d", light: "#d9ff5c", motif: "bolt", center: "bolt" }, bg: "var(--tangerine)" },
  { id: "crush", name: "The Crush", color: "Bubblegum", vibe: "hopeless romantic", blurb: "Hearts all over. Wear it on your sleeve (or wrist).", price: 26, tag: "new",
    colorway: { base: "#ff7ac0", ink: "#5a1240", pop: "#f2482f", light: "#fff3e6", motif: "heart", center: "heart" }, bg: "var(--mint)" },
];
const byId = (id: string) => products.find((p) => p.id === id);
const money = (v: number) => `$${v.toFixed(2)}`;
const photo = (name: string) => `./assets/rookigoods/${name}`;

/* ───────────────────────── routing ───────────────────────── */

function useRoute() {
  const read = () => (window.location.hash.startsWith("#/") ? window.location.hash.slice(1) : "/");
  const [path, setPath] = useState(read);
  useEffect(() => {
    const on = () => setPath(read());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  const navigate = (next: string) => {
    if (next !== path) window.location.hash = next;
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  };
  return { path, navigate };
}

function useStoredCart() {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const raw = localStorage.getItem("rooki-cart");
      const parsed = raw ? (JSON.parse(raw) as CartItem[]) : [];
      return parsed.filter((i) => byId(i.id) && i.qty > 0);
    } catch {
      return [];
    }
  });
  useEffect(() => {
    try { localStorage.setItem("rooki-cart", JSON.stringify(cart)); } catch { /* private mode */ }
  }, [cart]);
  return [cart, setCart] as const;
}

/* ───────────────────────── confetti ───────────────────────── */

function burst(x: number, y: number) {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const colors = ["#ff3b30", "#2b3bff", "#ffd23f", "#c8ff3d", "#ff8ad8"];
  for (let i = 0; i < 26; i++) {
    const s = document.createElement("i");
    s.className = "confetti";
    s.style.left = `${x}px`;
    s.style.top = `${y}px`;
    s.style.background = colors[i % colors.length];
    s.style.setProperty("--dx", `${(Math.random() - 0.5) * 320}px`);
    s.style.setProperty("--dy", `${-80 - Math.random() * 220}px`);
    s.style.setProperty("--r", `${Math.random() * 720 - 360}deg`);
    document.body.appendChild(s);
    window.setTimeout(() => s.remove(), 1100);
  }
}

/* ───────────────────────── app ───────────────────────── */

type Order = { number: string; email: string; name: string; address: string; items: CartItem[]; total: number; demo: boolean };
type Nav = (p: string) => void;
type Add = (p: Product, qty?: number, e?: React.MouseEvent) => void;

export default function App() {
  const { path, navigate } = useRoute();
  const [cart, setCart] = useStoredCart();
  const [cartOpen, setCartOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [toast, setToast] = useState("");
  const [order, setOrder] = useState<Order | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  const count = cart.reduce((n, i) => n + i.qty, 0);
  const subtotal = cart.reduce((n, i) => n + i.qty * (byId(i.id)?.price ?? 0), 0);

  const go: Nav = (p) => { setCartOpen(false); setMenuOpen(false); navigate(p); };
  const add: Add = (p, qty = 1, e) => {
    setCart((cur) => (cur.some((i) => i.id === p.id) ? cur.map((i) => (i.id === p.id ? { ...i, qty: i.qty + qty } : i)) : [...cur, { id: p.id, qty }]));
    if (e) burst(e.clientX, e.clientY);
    setToast(`${p.name} is in your bag`);
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 2200);
  };
  const setQty = (id: string, qty: number) => setCart((cur) => cur.flatMap((i) => (i.id === id ? (qty > 0 ? [{ ...i, qty }] : []) : [i])));

  const product = path.startsWith("/product/") ? byId(path.split("/")[2]) : undefined;
  const page = (() => {
    if (path === "/") return <Home go={go} add={add} />;
    if (path === "/shop") return <Shop go={go} add={add} />;
    if (product) return <ProductPage key={product.id} product={product} go={go} add={add} />;
    if (path === "/story") return <Story go={go} />;
    if (path === "/ways-to-wear") return <WaysToWear go={go} />;
    if (path === "/bag") return <BagPage cart={cart} subtotal={subtotal} go={go} setQty={setQty} />;
    if (path === "/checkout") return <Checkout cart={cart} subtotal={subtotal} go={go} onPlaced={(o) => { setOrder(o); setCart([]); go("/confirmation"); }} />;
    if (path === "/confirmation") return <Confirmation order={order} go={go} />;
    return <NotFound go={go} />;
  })();

  return (
    <div className="shell">
      <a className="skip" href="#main">skip to content</a>
      <div className="announce"><Marquee items={["free shipping on $50+", "100% cotton", "22 × 22 inches of possibility", "no rules. just rooki."]} /></div>
      <header className="header">
        <button className="logo" onClick={() => go("/")} aria-label="rooki goods home">rooki<span>goods</span></button>
        <nav className="nav">
          <button onClick={() => go("/shop")}>shop</button>
          <button onClick={() => go("/ways-to-wear")}>how to tie</button>
          <button onClick={() => go("/story")}>our story</button>
        </nav>
        <div className="header-actions">
          <button className="bag-btn" onClick={() => setCartOpen(true)} aria-label={`Open bag, ${count} items`}>
            <ShoppingBag size={18} /> <span>bag</span> <b key={count} className="bag-count">{count}</b>
          </button>
          <button className="menu-btn" onClick={() => setMenuOpen((o) => !o)} aria-label="Menu" aria-expanded={menuOpen}>{menuOpen ? <X size={22} /> : <Menu size={22} />}</button>
        </div>
      </header>
      {menuOpen && (
        <div className="mobile-menu">
          {[["shop all", "/shop"], ["how to tie", "/ways-to-wear"], ["our story", "/story"], ["your bag", "/bag"]].map(([l, p], i) => (
            <button key={p} onClick={() => go(p)} style={{ ["--i" as string]: i }}><span>0{i + 1}</span>{l}<ArrowUpRight /></button>
          ))}
        </div>
      )}
      <main id="main">{page}</main>
      {path !== "/checkout" && <Footer go={go} />}
      {cartOpen && <CartDrawer cart={cart} subtotal={subtotal} go={go} setQty={setQty} onClose={() => setCartOpen(false)} />}
      {toast && <div className="toast" role="status"><Check size={16} /> {toast} <button onClick={() => go("/bag")}>view</button></div>}
    </div>
  );
}

/* ───────────────────────── bits ───────────────────────── */

function Marquee({ items, className = "" }: { items: string[]; className?: string }) {
  const row = [...items, ...items, ...items];
  return (
    <div className={`marquee ${className}`} aria-label={items.join(", ")}>
      <div className="marquee-track" aria-hidden>
        {[0, 1].map((k) => <span key={k}>{row.map((t, i) => <span key={i}>{t} <i>✺</i> </span>)}</span>)}
      </div>
    </div>
  );
}

function SpinBadge({ text, className = "" }: { text: string; className?: string }) {
  const id = useMemo(() => `c${Math.random().toString(36).slice(2, 8)}`, []);
  return (
    <svg className={`spin-badge ${className}`} viewBox="0 0 120 120" aria-hidden>
      <defs><path id={id} d="M60,60 m-44,0 a44,44 0 1,1 88,0 a44,44 0 1,1 -88,0" /></defs>
      <circle cx="60" cy="60" r="58" />
      <text><textPath href={`#${id}`}>{text}</textPath></text>
    </svg>
  );
}

function ProductCard({ p, go, add, i = 0 }: { p: Product; go: Nav; add: Add; i?: number }) {
  return (
    <article className="card" style={{ ["--bg" as string]: p.bg, ["--tilt" as string]: `${[-2, 1.5, -1, 2, -1.5, 1][i % 6]}deg` }}>
      <button className="card-art" onClick={() => go(`/product/${p.id}`)} aria-label={`View ${p.name}`}>
        <Bandana colorway={p.colorway} className="card-bandana" label={`${p.name} bandana, ${p.color}`} />
        {p.tag && <span className="sticker">{p.tag}</span>}
      </button>
      <div className="card-body">
        <div>
          <h3>{p.name}</h3>
          <p>{p.color} · <em>{p.vibe}</em></p>
        </div>
        <strong>{money(p.price)}</strong>
      </div>
      <button className="btn btn-ink card-add" onClick={(e) => add(p, 1, e)}>add to bag <Plus size={16} /></button>
    </article>
  );
}

function Signup() {
  const [done, setDone] = useState(false);
  return (
    <section className="signup">
      <div className="wrap signup-inner">
        <div>
          <h2>Get the <em>good mail.</em></h2>
          <p>New drops, tying tricks, and first dibs on limited colors. No spam, pinky promise.</p>
        </div>
        {done ? (
          <p className="signup-done"><Sparkles size={18} /> You’re on the list. Welcome to the crew!</p>
        ) : (
          <form onSubmit={(e) => { e.preventDefault(); setDone(true); }}>
            <input type="email" required placeholder="you@email.com" aria-label="Email address" />
            <button className="btn btn-lime" type="submit">I’m in <ArrowRight size={16} /></button>
          </form>
        )}
      </div>
    </section>
  );
}

function Footer({ go }: { go: Nav }) {
  return (
    <footer className="footer">
      <div className="wrap footer-grid">
        <div>
          <span className="label">shop</span>
          <button onClick={() => go("/shop")}>all bandanas</button>
          {products.slice(0, 3).map((p) => <button key={p.id} onClick={() => go(`/product/${p.id}`)}>{p.name}</button>)}
        </div>
        <div>
          <span className="label">rooki world</span>
          <button onClick={() => go("/story")}>our story</button>
          <button onClick={() => go("/ways-to-wear")}>how to tie</button>
          <a href={STORE.instagram} target="_blank" rel="noreferrer">instagram</a>
          <a href={`mailto:${STORE.email}`}>{STORE.email}</a>
        </div>
        <div className="footer-note">
          <span className="label">the fine print</span>
          <p>Free US shipping over ${STORE.freeShippingOver}. Unworn bandanas can come back within 30 days.</p>
        </div>
      </div>
      <div className="footer-word" aria-hidden>rooki<span>goods</span></div>
      <div className="wrap footer-bottom"><span>© {new Date().getFullYear()} Rooki Goods</span><span>small square. big energy.</span></div>
    </footer>
  );
}

/* ───────────────────────── home ───────────────────────── */

function Home({ go, add }: { go: Nav; add: Add }) {
  const [hero, setHero] = useState(0);
  const [spin, setSpin] = useState(0);
  const p = products[hero];
  const shuffle = () => { setHero((h) => (h + 1 + Math.floor(Math.random() * (products.length - 1))) % products.length); setSpin((s) => s + 1); };

  return (
    <>
      <section className="hero" style={{ ["--hero" as string]: p.colorway.base }}>
        <div className="wrap hero-grid">
          <div className="hero-copy">
            <span className="pill">✺ bandanas for anyone</span>
            <h1>Small square.<br /><span className="big">BIG</span> <em>energy.</em></h1>
            <p>Loud little cotton squares for your neck, your hair, your bag, your dog. Six colorways, zero rules.</p>
            <div className="hero-ctas">
              <button className="btn btn-ink" onClick={() => go("/shop")}>shop the drop <ArrowUpRight size={18} /></button>
              <button className="btn btn-ghost" onClick={shuffle}><Shuffle size={17} /> shuffle my vibe</button>
            </div>
          </div>
          <div className="hero-stage">
            <div className="hero-blob" />
            <button className="hero-bandana" key={spin} onClick={() => go(`/product/${p.id}`)} aria-label={`View ${p.name}`}>
              <Bandana colorway={p.colorway} label={`${p.name} bandana`} />
            </button>
            <SpinBadge text="✺ 100% cotton ✺ 100% your thing " className="hero-spin" />
            <div className="hero-tag">
              <b>{p.name}</b>
              <span>{p.color} · {p.vibe}</span>
              <button onClick={(e) => add(p, 1, e)}>add {money(p.price)} <Plus size={14} /></button>
            </div>
            <div className="dots" role="group" aria-label="Pick a colorway">
              {products.map((q, i) => (
                <button key={q.id} className={i === hero ? "on" : ""} style={{ background: q.colorway.base }} onClick={() => { setHero(i); setSpin((s) => s + 1); }} aria-label={q.name} aria-pressed={i === hero} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <Marquee className="tilt" items={["tie it", "twist it", "knot it", "rock it", "lend it (maybe)"]} />

      <section className="section">
        <div className="wrap">
          <div className="section-head">
            <h2>Pick your <em>personality.</em></h2>
            <button className="link" onClick={() => go("/shop")}>shop all {products.length} <ArrowRight size={16} /></button>
          </div>
          <div className="grid">{products.slice(0, 3).map((q, i) => <ProductCard key={q.id} p={q} go={go} add={add} i={i} />)}</div>
        </div>
      </section>

      <Quiz go={go} />

      <section className="section ways-teaser">
        <div className="wrap">
          <div className="section-head">
            <h2>One square,<br /><em>a million looks.</em></h2>
            <button className="link" onClick={() => go("/ways-to-wear")}>all the ways <ArrowRight size={16} /></button>
          </div>
          <div className="ways-row">
            {wearWays.slice(0, 4).map((w, i) => (
              <button key={w.title} className="way" style={{ ["--bg" as string]: w.bg }} onClick={() => go("/ways-to-wear")}>
                <span className="way-num">0{i + 1}</span>
                <TieArt kind={w.kind} colorway={products[w.pi].colorway} />
                <b>{w.title}</b>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="section crew">
        <div className="wrap">
          <div className="section-head">
            <h2>The <em>rooki crew.</em></h2>
            <a className="link" href={STORE.instagram} target="_blank" rel="noreferrer">tag @rookigoods <ArrowUpRight size={16} /></a>
          </div>
          <div className="polaroids">
            {[
              ["male-bandana-profile.jpg", "good on anyone", "var(--lilac)"],
              ["male-bandana-portrait.jpg", "golden hour mood", "var(--tangerine)"],
              ["male-bandana-resting.jpg", "sunday, all day", "var(--mint)"],
              ["male-bandana-yellow.jpg", "butter? better.", "var(--bubble)"],
            ].map(([src, cap, bg], i) => (
              <figure key={src} className="polaroid" style={{ ["--bg" as string]: bg, ["--tilt" as string]: `${[-4, 3, -2, 4][i]}deg` }}>
                <div className="duo"><img src={photo(src)} alt={`Rooki crew member: ${cap}`} loading="lazy" /></div>
                <figcaption>{cap}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className="promise">
        <div className="wrap promise-grid">
          {[["🌱", "100% cotton", "Soft from day one, softer every wash."], ["📦", `free over $${STORE.freeShippingOver}`, "Standard US shipping on us."], ["↺", "30-day returns", "Not your vibe? Send it back."]].map(([icon, t, d]) => (
            <div key={t}><span>{icon}</span><b>{t}</b><p>{d}</p></div>
          ))}
        </div>
      </section>
      <Signup />
    </>
  );
}

/* ───────────────────────── quiz ───────────────────────── */

const quizAnswers = [
  { label: "front row at a show", emoji: "🎸", id: "night-owl" },
  { label: "picnic in the park", emoji: "🧺", id: "happy-hour" },
  { label: "lost on a hike", emoji: "🍄", id: "field-trip" },
  { label: "staring at clouds", emoji: "☁️", id: "daydream" },
  { label: "date night", emoji: "💌", id: "crush" },
  { label: "a classic diner", emoji: "🍒", id: "classic" },
];

function Quiz({ go }: { go: Nav }) {
  const [pick, setPick] = useState<string | null>(null);
  const result = pick ? byId(pick) : undefined;
  return (
    <section className="quiz">
      <div className="wrap quiz-grid">
        <div>
          <span className="pill pill-light">✺ 5-second quiz</span>
          <h2>Your perfect Saturday is…</h2>
          <div className="quiz-options">
            {quizAnswers.map((a) => (
              <button key={a.id} className={pick === a.id ? "on" : ""} onClick={() => setPick(a.id)}><span>{a.emoji}</span>{a.label}</button>
            ))}
          </div>
        </div>
        <div className="quiz-result" aria-live="polite">
          {result ? (
            <div className="quiz-card" key={result.id}>
              <Bandana colorway={result.colorway} label={result.name} />
              <span>you’re totally</span>
              <h3>{result.name}</h3>
              <p>{result.blurb}</p>
              <button className="btn btn-lime" onClick={() => go(`/product/${result.id}`)}>meet your match <ArrowRight size={16} /></button>
            </div>
          ) : (
            <div className="quiz-empty"><span>?</span><p>pick one and we’ll match you with your square</p></div>
          )}
        </div>
      </div>
    </section>
  );
}

/* ───────────────────────── tie illustrations ───────────────────────── */

type TieKind = "neck" | "head" | "bag" | "wrist" | "triangle" | "roll";

function TieArt({ kind, colorway }: { kind: TieKind; colorway: Colorway }) {
  const clip = { neck: "triangle", head: "roll", bag: "bow", wrist: "roll", triangle: "triangle", roll: "roll" }[kind];
  return (
    <div className={`tie tie-${kind}`}>
      <div className={`tie-cloth clip-${clip}`}><Bandana colorway={colorway} still /></div>
      {kind === "bag" && <div className="fig fig-bag" />}
      {kind === "head" && <div className="fig fig-head" />}
      {kind === "neck" && <div className="fig fig-neck" />}
      {kind === "wrist" && <div className="fig fig-wrist" />}
    </div>
  );
}

const wearWays: { kind: TieKind; title: string; copy: string; steps: string[]; pi: number; bg: string }[] = [
  { kind: "neck", title: "The neck tie", copy: "The French-cafe classic. Instantly makes a plain tee an outfit.", steps: ["Fold corner to corner into a triangle.", "Drape the point down your front.", "Tie the ends loosely behind, or knot to the side."], pi: 0, bg: "var(--butter)" },
  { kind: "head", title: "The headband", copy: "Bad hair day? Never heard of her.", steps: ["Fold into a triangle, then roll from the long edge.", "Wrap around your head, ends at the nape.", "Double knot underneath your hair."], pi: 1, bg: "var(--bubble)" },
  { kind: "bag", title: "The bag buddy", copy: "Give your tote a personality transplant.", steps: ["Roll into a skinny strip.", "Loop it around a bag handle.", "Tie a bow and let the tails fly."], pi: 3, bg: "var(--lilac)" },
  { kind: "wrist", title: "The wrist wrap", copy: "A little color for your hands-on days.", steps: ["Roll into a thin strip.", "Wrap twice around your wrist.", "Tuck or knot the ends."], pi: 5, bg: "var(--mint)" },
];

/* ───────────────────────── shop ───────────────────────── */

function Shop({ go, add }: { go: Nav; add: Add }) {
  const [filter, setFilter] = useState("everything");
  const [sort, setSort] = useState("featured");
  const list = products
    .filter((p) => filter === "everything" || (filter === "new & limited" ? p.tag === "new" || p.tag === "limited" : p.tag === "bestseller" || p.id === "daydream"))
    .sort((a, b) => (sort === "low" ? a.price - b.price : sort === "high" ? b.price - a.price : 0));
  return (
    <>
      <section className="page-hero" style={{ ["--bg" as string]: "var(--butter)" }}>
        <div className="wrap page-hero-grid">
          <div>
            <span className="pill">✺ the whole drop</span>
            <h1>Find your <em>kind of loud.</em></h1>
            <p>Six cotton squares, 22 × 22 inches each. Same great feel, very different moods.</p>
          </div>
          <div className="stack" aria-hidden>
            {products.slice(0, 3).map((p, i) => <div key={p.id} style={{ ["--i" as string]: i }}><Bandana colorway={p.colorway} still /></div>)}
          </div>
        </div>
      </section>
      <section className="section">
        <div className="wrap">
          <div className="toolbar">
            <div className="chips" role="group" aria-label="Filter">
              {["everything", "fan faves", "new & limited"].map((f) => <button key={f} className={filter === f ? "on" : ""} aria-pressed={filter === f} onClick={() => setFilter(f)}>{f}</button>)}
            </div>
            <label className="sort">sort
              <select value={sort} onChange={(e) => setSort(e.target.value)}>
                <option value="featured">featured</option>
                <option value="low">price: low → high</option>
                <option value="high">price: high → low</option>
              </select>
            </label>
          </div>
          <div className="grid">{list.map((p, i) => <ProductCard key={p.id} p={p} go={go} add={add} i={i} />)}</div>
        </div>
      </section>
      <Signup />
    </>
  );
}

/* ───────────────────────── product ───────────────────────── */

function ProductPage({ product: p, go, add }: { product: Product; go: Nav; add: Add }) {
  const [qty, setQty] = useState(1);
  const [open, setOpen] = useState<string>("the details");
  const info: [string, string][] = [
    ["the details", "100% cotton. 22 × 22 inches (56 × 56 cm). Hemmed edges. Printed edge to edge so both sides look good."],
    ["care", "Machine wash cold with similar colors, line dry. Warm iron if you’re fancy. It gets softer every wash."],
    ["shipping & returns", `Ships in 1–2 business days. Free US shipping over $${STORE.freeShippingOver}, otherwise $${STORE.flatShipping}. Unworn bandanas can come back within 30 days.`],
  ];
  const others = products.filter((q) => q.id !== p.id);
  return (
    <>
      <div className="wrap crumbs"><button onClick={() => go("/shop")}><ArrowLeft size={15} /> shop</button><span>/ {p.name}</span></div>
      <section className="wrap pdp">
        <div className="pdp-art" style={{ ["--bg" as string]: p.bg }}>
          <Bandana colorway={p.colorway} className="pdp-bandana" label={`${p.name} bandana, ${p.color}`} />
          {p.tag && <span className="sticker big">{p.tag}</span>}
          <SpinBadge text="✺ 22 × 22 in ✺ 100% cotton " className="pdp-spin" />
        </div>
        <div className="pdp-info">
          <span className="pill">✺ {p.vibe}</span>
          <h1>{p.name}</h1>
          <p className="pdp-price">{money(p.price)}</p>
          <p className="pdp-blurb">{p.blurb} Soft, 100% cotton and ready for your neck, hair, bag or wherever your day goes.</p>
          <div className="swatches">
            <span>color: <b>{p.color}</b></span>
            <div>
              {products.map((q) => <button key={q.id} className={q.id === p.id ? "on" : ""} style={{ background: q.colorway.base }} onClick={() => go(`/product/${q.id}`)} aria-label={`${q.name}, ${q.color}`} aria-current={q.id === p.id} />)}
            </div>
          </div>
          <div className="buy">
            <div className="qty">
              <button onClick={() => setQty(Math.max(1, qty - 1))} aria-label="Fewer"><Minus size={15} /></button>
              <span aria-live="polite">{qty}</span>
              <button onClick={() => setQty(qty + 1)} aria-label="More"><Plus size={15} /></button>
            </div>
            <button className="btn btn-ink grow" onClick={(e) => add(p, qty, e)}>add to bag · {money(p.price * qty)}</button>
          </div>
          <p className="fine">✓ ships in 1–2 days &nbsp; ✓ free over ${STORE.freeShippingOver} &nbsp; ✓ 30-day returns</p>
          <div className="accordion">
            {info.map(([t, c]) => (
              <div key={t} className={open === t ? "open" : ""}>
                <button onClick={() => setOpen(open === t ? "" : t)} aria-expanded={open === t}>{t}<ChevronDown size={18} /></button>
                {open === t && <p>{c}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>
      <Marquee className="tilt alt" items={[`${p.name.toLowerCase()}`, p.color.toLowerCase(), p.vibe]} />
      <section className="section">
        <div className="wrap">
          <div className="section-head"><h2>Collect the <em>whole crew.</em></h2></div>
          <div className="grid">{others.slice(0, 3).map((q, i) => <ProductCard key={q.id} p={q} go={go} add={add} i={i} />)}</div>
        </div>
      </section>
    </>
  );
}

/* ───────────────────────── story & ways ───────────────────────── */

function Story({ go }: { go: Nav }) {
  return (
    <>
      <section className="page-hero" style={{ ["--bg" as string]: "var(--bubble)" }}>
        <div className="wrap page-hero-grid">
          <div>
            <span className="pill">✺ the rooki way</span>
            <h1>Less ordinary. <em>More you.</em></h1>
            <p>Rooki Goods started with one small square and a very big belief: the stuff you use every day should bring a little joy with it.</p>
          </div>
          <div className="duo story-photo"><img src={photo("male-bandana-portrait.jpg")} alt="Someone wearing a red bandana in the sun" /></div>
        </div>
      </section>
      <section className="section">
        <div className="wrap principles">
          {[["01", "good stuff.", "100% cotton you can wear, wash and rewear for years.", "var(--lilac)"], ["02", "good color.", "Prints loud enough to make a regular Tuesday feel less regular.", "var(--butter)"], ["03", "good people.", "For anyone, any style, any day. However you tie it is right.", "var(--mint)"]].map(([n, t, c, bg]) => (
            <div key={n} style={{ ["--bg" as string]: bg }}><span>{n}</span><h3>{t}</h3><p>{c}</p></div>
          ))}
        </div>
      </section>
      <section className="big-cta">
        <div className="wrap">
          <h2>Come as <em>you are.</em></h2>
          <button className="btn btn-lime" onClick={() => go("/shop")}>shop the bandanas <ArrowUpRight size={18} /></button>
        </div>
      </section>
      <Signup />
    </>
  );
}

function WaysToWear({ go }: { go: Nav }) {
  return (
    <>
      <section className="page-hero" style={{ ["--bg" as string]: "var(--mint)" }}>
        <div className="wrap page-hero-grid">
          <div>
            <span className="pill">✺ how to tie</span>
            <h1>No right way. <em>Just your way.</em></h1>
            <p>Every look starts with one of two folds: the <b>triangle</b> (corner to corner) or the <b>roll</b> (triangle, then roll from the long edge). Pick one and go.</p>
          </div>
          <div className="folds">
            <div><TieArt kind="triangle" colorway={products[0].colorway} /><b>the triangle</b></div>
            <div><TieArt kind="roll" colorway={products[1].colorway} /><b>the roll</b></div>
          </div>
        </div>
      </section>
      <section className="section">
        <div className="wrap ways-list">
          {wearWays.map((w, i) => (
            <article key={w.title} className="way-step" style={{ ["--bg" as string]: w.bg }}>
              <div className="way-art"><TieArt kind={w.kind} colorway={products[w.pi].colorway} /></div>
              <div>
                <span className="way-num">0{i + 1}</span>
                <h2>{w.title}</h2>
                <p>{w.copy}</p>
                <ol>{w.steps.map((s) => <li key={s}>{s}</li>)}</ol>
                <button className="btn btn-ink" onClick={() => go(`/product/${products[w.pi].id}`)}>try it with {products[w.pi].name} <ArrowUpRight size={16} /></button>
              </div>
            </article>
          ))}
        </div>
      </section>
      <Signup />
    </>
  );
}

/* ───────────────────────── bag & checkout ───────────────────────── */

function Line({ item, setQty, compact }: { item: CartItem; setQty: (id: string, q: number) => void; compact?: boolean }) {
  const p = byId(item.id)!;
  return (
    <div className={`line ${compact ? "compact" : ""}`}>
      <div className="line-art" style={{ ["--bg" as string]: p.bg }}><Bandana colorway={p.colorway} still label={p.name} /></div>
      <div className="line-info">
        <b>{p.name}</b>
        <span>{p.color} · {money(p.price)}</span>
        <div className="line-ctrl">
          <div className="qty small">
            <button onClick={() => setQty(p.id, item.qty - 1)} aria-label={`Fewer ${p.name}`}><Minus size={13} /></button>
            <span>{item.qty}</span>
            <button onClick={() => setQty(p.id, item.qty + 1)} aria-label={`More ${p.name}`}><Plus size={13} /></button>
          </div>
          <button className="remove" onClick={() => setQty(p.id, 0)}>remove</button>
        </div>
      </div>
      <strong>{money(p.price * item.qty)}</strong>
    </div>
  );
}

const shippingFor = (subtotal: number) => (subtotal === 0 || subtotal >= STORE.freeShippingOver ? 0 : STORE.flatShipping);

function ShipMeter({ subtotal }: { subtotal: number }) {
  const left = Math.max(0, STORE.freeShippingOver - subtotal);
  return (
    <div className="meter">
      <p>{left === 0 ? "🎉 You unlocked free shipping!" : <>You’re <b>{money(left)}</b> away from free shipping</>}</p>
      <div><i style={{ width: `${Math.min(100, (subtotal / STORE.freeShippingOver) * 100)}%` }} /></div>
    </div>
  );
}

function CartDrawer({ cart, subtotal, go, setQty, onClose }: { cart: CartItem[]; subtotal: number; go: Nav; setQty: (id: string, q: number) => void; onClose: () => void }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div className="drawer-bg" onClick={onClose}>
      <aside className="drawer" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="Your bag">
        <div className="drawer-head"><h2>your bag</h2><button onClick={onClose} aria-label="Close"><X /></button></div>
        {cart.length ? (
          <>
            <ShipMeter subtotal={subtotal} />
            <div className="drawer-lines">{cart.map((i) => <Line key={i.id} item={i} setQty={setQty} compact />)}</div>
            <div className="drawer-foot">
              <div className="row"><span>subtotal</span><b>{money(subtotal)}</b></div>
              <button className="btn btn-ink full" onClick={() => go("/checkout")}>checkout <ArrowRight size={16} /></button>
              <button className="link center" onClick={() => go("/bag")}>view full bag</button>
            </div>
          </>
        ) : (
          <div className="empty">
            <Bandana colorway={products[Math.floor(Math.random() * products.length)].colorway} still />
            <h3>Your bag is feeling empty.</h3>
            <button className="btn btn-ink" onClick={() => go("/shop")}>fill it up <ArrowUpRight size={16} /></button>
          </div>
        )}
      </aside>
    </div>
  );
}

function Summary({ cart, subtotal, children }: { cart: CartItem[]; subtotal: number; children?: React.ReactNode }) {
  const ship = shippingFor(subtotal);
  return (
    <aside className="summary">
      <h2>summary</h2>
      {cart.map((i) => { const p = byId(i.id)!; return <div key={i.id} className="row"><span>{p.name} × {i.qty}</span><b>{money(p.price * i.qty)}</b></div>; })}
      <hr />
      <div className="row"><span>subtotal</span><b>{money(subtotal)}</b></div>
      <div className="row"><span>shipping</span><b>{ship === 0 ? "free!" : money(ship)}</b></div>
      <div className="row muted"><span>tax</span><b>calculated at payment</b></div>
      <div className="row total"><span>total</span><b>{money(subtotal + ship)}</b></div>
      {children}
    </aside>
  );
}

function BagPage({ cart, subtotal, go, setQty }: { cart: CartItem[]; subtotal: number; go: Nav; setQty: (id: string, q: number) => void }) {
  return (
    <section className="wrap section bag">
      <h1>Your <em>happy haul.</em></h1>
      {cart.length === 0 ? (
        <div className="empty big"><h3>Nothing here yet.</h3><p>Lots of good squares are waiting for you.</p><button className="btn btn-ink" onClick={() => go("/shop")}>shop bandanas <ArrowUpRight size={16} /></button></div>
      ) : (
        <div className="bag-grid">
          <div>
            <ShipMeter subtotal={subtotal} />
            {cart.map((i) => <Line key={i.id} item={i} setQty={setQty} />)}
            <button className="link" onClick={() => go("/shop")}><ArrowLeft size={16} /> keep shopping</button>
          </div>
          <Summary cart={cart} subtotal={subtotal}><button className="btn btn-ink full" onClick={() => go("/checkout")}>checkout <ArrowRight size={16} /></button></Summary>
        </div>
      )}
    </section>
  );
}

function Checkout({ cart, subtotal, go, onPlaced }: { cart: CartItem[]; subtotal: number; go: Nav; onPlaced: (o: Order) => void }) {
  const total = subtotal + shippingFor(subtotal);
  const links = cart.map((i) => STORE.paymentLinks[i.id]).filter(Boolean);
  const stripeReady = cart.length === 1 && links.length === 1;
  const liveMode = Object.values(STORE.paymentLinks).some(Boolean);

  if (!cart.length) {
    return <section className="wrap section"><div className="empty big"><h3>Your bag is empty.</h3><button className="btn btn-ink" onClick={() => go("/shop")}>shop bandanas</button></div></section>;
  }
  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const email = String(f.get("email"));
    if (stripeReady) {
      const url = new URL(links[0]);
      url.searchParams.set("prefilled_email", email);
      window.location.href = url.toString();
      return;
    }
    onPlaced({
      number: `RG-${Math.floor(1000 + Math.random() * 9000)}`,
      email,
      name: `${f.get("first")} ${f.get("last")}`,
      address: `${f.get("street")}, ${f.get("city")}, ${f.get("state")} ${f.get("zip")}`,
      items: cart,
      total,
      demo: true,
    });
  };
  return (
    <section className="wrap section checkout">
      <button className="link" onClick={() => go("/bag")}><ArrowLeft size={16} /> back to bag</button>
      <h1>Almost <em>yours.</em></h1>
      <div className="bag-grid">
        <form className="co-form" onSubmit={submit}>
          <fieldset><legend><span>1</span> you</legend>
            <label>email<input name="email" type="email" autoComplete="email" required /></label>
          </fieldset>
          <fieldset><legend><span>2</span> where’s it going?</legend>
            <div className="two"><label>first name<input name="first" autoComplete="given-name" required /></label><label>last name<input name="last" autoComplete="family-name" required /></label></div>
            <label>street address<input name="street" autoComplete="street-address" required /></label>
            <div className="three"><label>city<input name="city" autoComplete="address-level2" required /></label><label>state<input name="state" autoComplete="address-level1" required /></label><label>zip<input name="zip" autoComplete="postal-code" inputMode="numeric" required /></label></div>
          </fieldset>
          <fieldset><legend><span>3</span> payment</legend>
            {stripeReady ? (
              <p className="note">🔒 You’ll finish paying on Stripe’s secure checkout. We never see your card number.</p>
            ) : liveMode ? (
              <p className="note warn">Online checkout handles one bandana style at a time for now. Check out each style separately, or email <a href={`mailto:${STORE.email}`}>{STORE.email}</a> and we’ll sort you out.</p>
            ) : (
              <p className="note warn">✺ Demo store: no payment is taken and nothing ships. (Store owner: add Stripe Payment Links in <code>store.config.ts</code> to go live.)</p>
            )}
          </fieldset>
          <button className="btn btn-ink full" type="submit" disabled={liveMode && !stripeReady}>{stripeReady ? `pay ${money(total)} with Stripe` : "place demo order"} <ArrowRight size={16} /></button>
        </form>
        <Summary cart={cart} subtotal={subtotal} />
      </div>
    </section>
  );
}

function Confirmation({ order, go }: { order: Order | null; go: Nav }) {
  useEffect(() => { if (order) burst(window.innerWidth / 2, window.innerHeight / 3); }, [order]);
  if (!order) return <NotFound go={go} />;
  return (
    <section className="wrap section confirm">
      <span className="pill">order {order.number}{order.demo ? " · demo" : ""}</span>
      <h1>Good things <em>are coming.</em></h1>
      <p>Thanks, {order.name.split(" ")[0]}! {order.demo ? "This was a demo order, so nothing was charged." : `A receipt is on its way to ${order.email}.`}</p>
      <div className="confirm-grid">
        <div className="confirm-card"><span className="label">shipping to</span><p>{order.name}<br />{order.address}</p></div>
        <div className="confirm-card"><span className="label">your squares</span>{order.items.map((i) => <p key={i.id}>{byId(i.id)!.name} × {i.qty}</p>)}<p><b>{money(order.total)}</b></p></div>
      </div>
      <button className="btn btn-ink" onClick={() => go("/ways-to-wear")}>learn a new tie while you wait <ArrowUpRight size={16} /></button>
    </section>
  );
}

function NotFound({ go }: { go: Nav }) {
  return (
    <section className="wrap section notfound">
      <Bandana colorway={products[4].colorway} still />
      <h1>This page <em>blew away.</em></h1>
      <button className="btn btn-ink" onClick={() => go("/")}>back home <ArrowUpRight size={16} /></button>
    </section>
  );
}
