import type React from "react";
import { useId } from "react";

/**
 * Original, procedurally drawn bandana artwork. Every colorway is pure SVG,
 * so product images are crisp at any size and never depend on a host.
 */

export type Motif = "paisley" | "sparkle" | "mushroom" | "cherry" | "heart" | "bolt";

export type Colorway = {
  base: string;
  ink: string;
  pop: string;
  light: string;
  motif: Motif;
  center: Motif;
};

const M: Record<Motif, (c: Colorway) => React.ReactElement> = {
  paisley: (c) => (
    <g>
      <path d="M0,-17 C13,-17 17,-1 9,11 C3,19 -10,19 -12,8 C-14,-2 -6,-7 0,-3 C4,0 2,6 -2,6" fill={c.light} />
      <circle cx="-1" cy="4" r="3.2" fill={c.ink} />
      <path d="M2,-12 C9,-11 12,-2 7,6" fill="none" stroke={c.pop} strokeWidth="2" strokeLinecap="round" />
    </g>
  ),
  sparkle: (c) => (
    <g>
      <path d="M0,-16 C2,-4 4,-2 16,0 C4,2 2,4 0,16 C-2,4 -4,2 -16,0 C-4,-2 -2,-4 0,-16Z" fill={c.light} />
      <circle r="3" fill={c.pop} />
    </g>
  ),
  mushroom: (c) => (
    <g>
      <path d="M-15,0 C-15,-12 15,-12 15,0 Z" fill={c.pop} />
      <rect x="-5" y="0" width="10" height="12" rx="4" fill={c.light} />
      <circle cx="-6" cy="-5" r="2.4" fill={c.light} />
      <circle cx="5" cy="-6" r="2" fill={c.light} />
    </g>
  ),
  cherry: (c) => (
    <g>
      <path d="M-6,4 C-4,-6 0,-12 6,-15 M6,4 C5,-4 5,-10 6,-15" fill="none" stroke={c.ink} strokeWidth="2.2" strokeLinecap="round" />
      <path d="M6,-15 C11,-17 15,-13 13,-10 C9,-10 7,-12 6,-15Z" fill={c.light} />
      <circle cx="-6" cy="8" r="6.5" fill={c.pop} />
      <circle cx="6" cy="8" r="6.5" fill={c.pop} />
      <circle cx="-8" cy="6" r="1.8" fill={c.light} />
      <circle cx="4" cy="6" r="1.8" fill={c.light} />
    </g>
  ),
  heart: (c) => (
    <g>
      <path d="M0,13 C-18,1 -14,-14 -6,-14 C-2,-14 0,-11 0,-8 C0,-11 2,-14 6,-14 C14,-14 18,1 0,13Z" fill={c.light} />
      <path d="M-7,-8 C-9,-6 -9,-3 -8,-1" stroke={c.pop} strokeWidth="2" fill="none" strokeLinecap="round" />
    </g>
  ),
  bolt: (c) => (
    <g>
      <path d="M3,-17 L-10,3 L-1,3 L-4,17 L10,-4 L1,-4 Z" fill={c.light} stroke={c.ink} strokeWidth="1.5" strokeLinejoin="round" />
    </g>
  ),
};

export function Bandana({ colorway, className, still, label }: { colorway: Colorway; className?: string; still?: boolean; label?: string }) {
  const uid = useId().replace(/:/g, "");
  const c = colorway;
  const Motif = M[c.motif];
  const Center = M[c.center];
  const field: React.ReactElement[] = [];
  for (let row = 0; row < 7; row++) {
    for (let col = 0; col < 7; col++) {
      const x = 92 + col * 36 + (row % 2 ? 18 : 0);
      const y = 92 + row * 36;
      const dx = x - 200, dy = y - 200;
      if (Math.hypot(dx, dy) < 62 || x > 316) continue;
      const rot = ((row * 7 + col) * 47) % 360;
      field.push(
        <g key={`${row}-${col}`} transform={`translate(${x} ${y}) rotate(${rot}) scale(.78)`}>
          {(row + col) % 3 === 0 ? <circle r="3.4" fill={c.pop} /> : <Motif {...c} />}
        </g>,
      );
    }
  }
  const borderDots: React.ReactElement[] = [];
  for (let i = 0; i < 17; i++) {
    const p = 40 + i * 20;
    borderDots.push(
      <circle key={`t${i}`} cx={p} cy="33" r="3.2" fill={c.light} />,
      <circle key={`b${i}`} cx={p} cy="367" r="3.2" fill={c.light} />,
      <circle key={`l${i}`} cx="33" cy={p} r="3.2" fill={c.light} />,
      <circle key={`r${i}`} cx="367" cy={p} r="3.2" fill={c.light} />,
    );
  }
  const corners = [
    [62, 62, 45],
    [338, 62, 135],
    [338, 338, 225],
    [62, 338, 315],
  ];
  return (
    <svg viewBox="0 0 400 400" className={className} role="img" aria-label={label ?? "bandana"} data-still={still ? "" : undefined}>
      <defs>
        <filter id={`cloth-${uid}`} x="-5%" y="-5%" width="110%" height="110%">
          <feTurbulence type="fractalNoise" baseFrequency="0.008" numOctaves="2" seed="7" />
          <feDisplacementMap in="SourceGraphic" scale="14" />
        </filter>
        <radialGradient id={`shade-${uid}`} cx="35%" cy="30%" r="85%">
          <stop offset="0" stopColor="#fff" stopOpacity=".28" />
          <stop offset=".55" stopColor="#fff" stopOpacity="0" />
          <stop offset="1" stopColor="#000" stopOpacity=".22" />
        </radialGradient>
        <linearGradient id={`fold-${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset=".48" stopColor="#000" stopOpacity="0" />
          <stop offset=".5" stopColor="#000" stopOpacity=".09" />
          <stop offset=".53" stopColor="#fff" stopOpacity=".1" />
          <stop offset=".56" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
      </defs>
      <g filter={`url(#cloth-${uid})`}>
        <rect x="14" y="14" width="372" height="372" rx="6" fill={c.base} />
        <rect x="14" y="14" width="372" height="372" rx="6" fill="none" stroke={c.ink} strokeWidth="10" />
        <rect x="48" y="48" width="304" height="304" fill="none" stroke={c.light} strokeWidth="2.5" strokeDasharray="1 7" strokeLinecap="round" />
        <rect x="54" y="54" width="292" height="292" fill="none" stroke={c.ink} strokeWidth="2" />
        {borderDots}
        {field}
        {corners.map(([x, y, r]) => (
          <g key={`${x}${y}`} transform={`translate(${x} ${y}) rotate(${r})`}>
            <circle r="17" fill={c.ink} />
            <g transform="scale(.7)"><Center {...c} /></g>
          </g>
        ))}
        <circle cx="200" cy="200" r="54" fill={c.ink} />
        <circle cx="200" cy="200" r="46" fill="none" stroke={c.light} strokeWidth="2.5" strokeDasharray="2 6" strokeLinecap="round" />
        {Array.from({ length: 8 }, (_, i) => (
          <g key={i} transform={`rotate(${i * 45} 200 200) translate(200 172) scale(.55)`}>
            <Center {...c} />
          </g>
        ))}
        <g transform="translate(200 200) scale(1.05)"><Center {...c} /></g>
        <rect x="14" y="14" width="372" height="372" rx="6" fill={`url(#shade-${uid})`} />
        <rect x="14" y="14" width="372" height="372" rx="6" fill={`url(#fold-${uid})`} />
      </g>
    </svg>
  );
}
