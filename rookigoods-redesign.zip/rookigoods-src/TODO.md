# Rooki Goods storefront

## Responsive Figma-matched customer journey
- [x] Build a responsive home page with the Figma-inspired bright blue, lemon yellow, lavender, peach, cream and navy visual system; include the editorial hero, promotional marquee, story sections, product rail, call-to-action bands and branded footer.
- [x] Build connected routes for home, Shop All, The Classic product detail, Our Story, Ways to Shop, Checkout, Order Confirmation and a 404 fallback.
- [x] Add site-wide desktop and mobile navigation with a persistent bag count and functional route transitions.

## Catalog and product interactions
- [x] Build a responsive Shop All product grid with product names, notes, prices, badges, product imagery and add-to-bag controls.
- [x] Build The Classic product detail pattern with prominent product visual, descriptive content, price, color choice, quantity selection and add-to-bag behavior; reuse the pattern for catalog products.
- [x] Add a cart drawer with line items, quantity updates, removal, subtotal, shipping note and checkout progression.

## Checkout and order confirmation
- [x] Add a responsive checkout flow with required contact, shipping and payment form fields and order summary.
- [x] Submit the checkout form into an order confirmation state with order number, thank-you messaging and a route back to shopping.
